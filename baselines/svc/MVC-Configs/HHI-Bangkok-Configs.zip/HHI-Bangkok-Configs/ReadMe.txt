**************************************************************
README File for Fraunhofer-HHI Multi-View Video Coding Package
**************************************************************


*Preparing the unzipped package for testing:

1. Copy the original YUV-files to the each of the eight \{Data Set}\origYUVs\ folder,
   by replacing the existing YUV dummy files. (!Important: filenames must be the same)
   
2. Copy the compiled Encoder ("H264AVCEncoderLibTestStatic.exe") 
   and Decoder ("H264AVCDecoderLibTestStatic.exe") executables to the \binaries folder.

   
*Multi-view Video Coding procedure:

Run the four consecutively numbered batch-scripts one after the other from the command line.
